package Utility;

public class Constant {

	public static final String URL = "https://www.flipkart.com";
	 
    public static final String projectPath = System.getProperty("user.dir");

    public static final String filePath = projectPath+"/src/TestData/SearchCriteria.xlsx";
    
    public static final String chromeDriverPath=projectPath+"/src/drivers/chromedriver.exe";

}
