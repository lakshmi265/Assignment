package Utility;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;

import org.apache.poi.xssf.usermodel.XSSFRow;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	
	static String ProjectPath;
	static XSSFWorkbook workBook;
	static XSSFSheet sheet;
	// setup excel and read the data
	public ExcelUtils(String excelPath,String sheetName)
	{
		try{
		
		workBook=new XSSFWorkbook(excelPath);
		sheet=workBook.getSheet(sheetName);
		
	}catch(Exception exp)
		{
		System.out.println(exp.getMessage());
		exp.getCause();
		exp.printStackTrace();
	}
	}
		// finding the no of rows in sheet
	public static void getRowCount()
	{
		try{
					
		int rowCount=sheet.getPhysicalNumberOfRows();		
		System.out.println("no of rows in sheet are" +rowCount);
		
		}
		catch(Exception exp)
		{
			System.out.println(exp.getMessage());
			exp.getCause();
			exp.printStackTrace();
		}
		
	} 
	// get string type cell data
	public static void getCellDataString(int rowNum,int colNum)
	{
		try{
			
			String MobileType=sheet.getRow(rowNum).getCell(colNum).getStringCellValue();
			String ram=sheet.getRow(rowNum).getCell(colNum).getStringCellValue();
			String processorBrand=sheet.getRow(rowNum).getCell(colNum).getStringCellValue();
			
			System.out.println(MobileType);
			System.out.println(ram);
			System.out.println(processorBrand);
			
			
		}catch(Exception exp)
		{
			System.out.println(exp.getMessage());
			exp.getCause();
			exp.printStackTrace();
		}
		
	}
	// get numeric type string data
	
	public static void getCellDataInteger(int rowNum,int colNum)
	{
		try{		
			
			Double Range=sheet.getRow(rowNum).getCell(colNum).getNumericCellValue();			
			System.out.println(Range);
				
		}catch(Exception exp)
		{
			System.out.println(exp.getMessage());
			exp.getCause();
			exp.printStackTrace();
		}
		
	}
	
	public void writeMobileDataIntoExcel()
	{
		
		
		
	}
}
