package Utility;

import Utility.Constant;

public class CallExcelUtils {
 
	public static void main(String[] args) {
	
		ExcelUtils excel=new ExcelUtils(Constant.filePath, "Search Criteria");
		
		excel.getRowCount();
		excel.getCellDataString(1,0);
		excel.getCellDataInteger(1, 1);
		excel.getCellDataString(1, 2);
		excel.getCellDataString(1, 3);
	}

}
