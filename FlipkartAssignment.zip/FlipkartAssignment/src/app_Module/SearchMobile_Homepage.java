package app_Module;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObjects.Home_Page;
import Utility.Constant;
import Utility.ExcelUtils;

public class SearchMobile_Homepage {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@BeforeClass
	 public void Setup()
	    {
	    	System.setProperty("webdriver.chrome.driver", Constant.chromeDriverPath);
	    	driver = new ChromeDriver();
	    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    	driver.get(Constant.URL);   
	    	driver.manage().window().maximize();
	    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    	driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
	    }
	 
	@Test(priority=0)
	 public void SearchMobile()
	 {
		WebElement searchText=driver.findElement(By.name("q"));
		searchText.sendKeys("samsung"); 
		
		List<WebElement> listofElements=driver.findElements(By.xpath("//ul[@class='col-12-12 _1PBbw8']"));
		System.out.println(listofElements.size());
		for(WebElement Element : listofElements) {
			//0System.out.println(Element.getText());
			if(Element.getText().trim().equals("samsung"));
			{
				Element.click();
				break;
			}
			
		}
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	 }
	
	@Test(priority=1)
	  public void applyFilterMobiles()
	  {
		  driver.get("https://www.flipkart.com/search?q=samsung&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off");
		  Select dropDown=new Select(driver.findElement(By.xpath("//div[@class='_1YoBfV']//select[@class='fPjUPw']")));
		  dropDown.selectByIndex(3);	
		  driver.manage().timeouts().implicitlyWait(6000, TimeUnit.SECONDS);
		 // System.out.println("reaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaached");
		  //WebElement element = driver.findElement(By.xpath("//div[@class='_1GEhLw'][contains(text(),'2 GB')]"));
		  //WebElement element = driver.findElement(By.xpath("//section[4]//div[2]//div[1]//div[4]//div[1]//div[1]//label[1]//div[1]"));
		  WebElement element = driver.findElement(By.cssSelector("div.t-0M7P._2doH3V div._3e7xtJ div._1HmYoV.hCUpcT:nth-child(1) div._1HmYoV._35HD7C:nth-child(1) div._1HmYoV._35HD7C.col-12-12 div.bhgxx2.col-12-12:nth-child(1) div._1YuAuf section._1gjf4c.D_NGuZ:nth-child(5) div._3mk-PQ div._36jUgy div._4IiNRh._2mtkou:nth-child(4) div._2wQvxh._1WV8jE div._2kFyHg._2mtkou label:nth-child(1) > div._1p7h2j"));
		  Actions action = new Actions(driver);
		  action.moveToElement(element).click().perform();
		 driver.manage().timeouts().implicitlyWait(6000, TimeUnit.SECONDS);
		 // driver.findElement(By.xpath("//div[contains(text(),'Snapdragon')]")).click();
		 driver.findElement(By.xpath("//body/div[@id='container']/div/div[@class='t-0M7P _2doH3V']/div[@class='_3e7xtJ']/div[@class='_1HmYoV hCUpcT']/div[@class='_1HmYoV _35HD7C']/div[@class='_1HmYoV _35HD7C col-12-12']/div[@class='bhgxx2 col-12-12']/div[@class='_1YuAuf']/section[16]/div[1]"));
		  //driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		  WebElement processorType = driver.findElement(By.xpath("//section[16]//div[2]//div[1]//div[3]//div[1]//div[1]//label[1]//div[1]"));
		  Actions processorTypeaction = new Actions(driver);
		  processorTypeaction.moveToElement(processorType).click().perform();
			 		  
	  }	
	
	@Test(priority=2)
	 public void writeDataIntoExcel()
	 {
		driver.findElement(By.xpath("//div[contains(text(),'Samsung Galaxy J2 2018 (Gold, 16 GB)')]")).click();
		// String resultMobile1=driver.findElement(By.xpath("//div[contains(text(),'Samsung Galaxy J2 2018 (Gold, 16 GB)')]")).getText();
		 //System.out.println(resultMobile1);
		 
	 }
	
	}

    